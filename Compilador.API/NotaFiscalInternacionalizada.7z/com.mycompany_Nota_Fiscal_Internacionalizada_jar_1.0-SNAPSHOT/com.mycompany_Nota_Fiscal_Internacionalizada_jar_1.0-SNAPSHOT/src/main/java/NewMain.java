
import com.mycompany.nota_fiscal_internacionalizada.Tela.TesteJFrame;

public class NewMain {

    public static void main(String[] args) {
        
         TesteJFrame telaTeste = new TesteJFrame();
         telaTeste.setVisible(true);
        
    }
    
}
