package com.mycompany.pdf;

import java.io.IOException;

public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        PDFGenerator pdfGenerator = new PDFGenerator();
        String conteudo = "TEXTO DE TESTE";
                
        PDFGenerator.createPDF("arquivo.pdf", "sadasd");
    }
    
}
