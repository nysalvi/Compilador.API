package com.mycompany.pdf;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

public class PDFGenerator {
        public static PDDocument loadPDF(String path) throws IOException{
                File file  = new File(path);
                if (!file.exists())
                    return null;
                PDDocument pdfDocument = Loader.loadPDF(file);                
                return pdfDocument;
        }
        public static void createPDF(String path, String content) throws IOException{
            
                File file = new File(path);
                if (file.exists()){
                    file.delete();
                }
                file.createNewFile();
                
                Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
                                
                PDDocument pdfDocument = new PDDocument();                
                PDPage page = new PDPage();
                
                PDPageContentStream pageStream = new PDPageContentStream(pdfDocument, page);
                pageStream.beginText();
                pageStream.setFont(PDType1Font.TIMES_ROMAN, 20);
                pageStream.setLeading(16.0f);

                pageStream.newLineAtOffset(0, dimension.height);
                pageStream.showText(content);
                pageStream.endText();
                pageStream.close();                
                
                pdfDocument.addPage(page);
                pdfDocument.save(file);
                pdfDocument.close();               
        }
}